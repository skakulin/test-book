

<?php $__env->startSection('content'); ?>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">ФИО</th>
            <th scope="col">Кол-во книг</th>
            <th scope="col"></th>
            <th scope="col"></th>
        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="col"><?php echo e($author->id); ?></td>
                    <td scope="col"><?php echo e($author->name); ?></td>
                    <td scope="col"><?php echo e(count($author->books)); ?></td>
                    <td scope="col"><a href="<?php echo e(route('editAuthor', ['id' => $author->id])); ?>">Редактировать</a></td>
                    <td scope="col"><a href="<?php echo e(route('deleteAuthor', ['id' => $author->id])); ?>">Удалить</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\books\resources\views/pages/authors.blade.php ENDPATH**/ ?>