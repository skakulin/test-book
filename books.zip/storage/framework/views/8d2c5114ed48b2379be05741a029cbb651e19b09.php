

<?php $__env->startSection('content'); ?>
    <?php if(Session::has('message')): ?>
        <p class="alert alert-info"><?php echo e(Session::get('message')); ?></p>
    <?php endif; ?>
    
    <h1 style="margin-top:100px">Главная</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\books\resources\views/pages/main.blade.php ENDPATH**/ ?>