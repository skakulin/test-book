

<?php $__env->startSection('content'); ?>
    <?php if(Session::has('message')): ?>
        <p class="alert alert-info"><?php echo e(Session::get('message')); ?></p>
    <?php endif; ?>

    <table class="table">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">ФИО</th>
            <th scope="col">Год выпуска</th>
            <th scope="col">Авторы</th>
            <th scope="col"></th>
            <th scope="col"></th>
        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="col"><?php echo e($book->id); ?></td>
                    <td scope="col"><?php echo e($book->name); ?></td>
                    <td scope="col"><?php echo e($book->year); ?></td>
                    <td scope="col">
                        <ul class="list-group">
                            <?php $__currentLoopData = $book->authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item"><?php echo e($author->name); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </td>
                    <td scope="col"><a href="<?php echo e(route('editBook', ['id' => $book->id])); ?>">Редактировать</a></td>
                    <td scope="col"><a href="<?php echo e(route('deleteBook', ['id' => $book->id])); ?>">Удалить</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer\domains\books\resources\views/pages/books.blade.php ENDPATH**/ ?>